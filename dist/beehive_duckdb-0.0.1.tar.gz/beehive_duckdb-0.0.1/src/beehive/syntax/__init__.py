from ..syntax import core as duckdb_syntax
