from typing import List


class Macro:
    def __init__(self, name: str, macro):
        self.name = name
        self.macro = macro
