class CreateSchema:
    def __init__(self, schema):
        self.schema = schema


class CreateTable:
    def __init__(self, table):
        self.table = table
