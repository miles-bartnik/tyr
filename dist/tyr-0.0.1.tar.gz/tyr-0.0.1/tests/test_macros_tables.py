import pytest


def test_event_time_interval_transform():
    assert False
